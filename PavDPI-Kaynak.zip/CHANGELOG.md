# Changelog

## 2.0.0 - 2026-08-27

- PavDPI kurucu ve servis katmanı Poroksima markasıyla yayınlandı.
- PavDPI temiz bir kaynak ağacında yeniden oluşturuldu.
- Doğrudan motor hizmeti yerine gerçek `PavDPI Service` denetleyicisi eklendi.
- Kırılgan `sc.exe` servis yolu oluşturma kodu Windows Service API ile değiştirildi.
- Arka plan süreç adları PavDPI markasına göre düzenlendi.
- Koyu küreli tek EXE kurucu arayüzü korundu ve yenilendi.
- Discord ve Roblox hedef listesi eklendi; sabit TTL genel web trafiğinden kaldırıldı.
- Otomatik bağlantı ayarı seçimi ve sağlık testi eklendi.
- Kurulum rollback'i artık eski hizmet tanımını ve çalışma durumunu da geri yükler.
- Güvenli ZIP çıkarma, eksiksiz manifest denetimi ve sabit üçüncü taraf hash'leri eklendi.
- Kaynak, bağlantı ayarı, servis denetleyicisi ve paket testleri genişletildi.
