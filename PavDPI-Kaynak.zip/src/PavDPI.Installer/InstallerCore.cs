using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Security.Cryptography;
using System.Security.Principal;
using System.Text;
using System.Threading;

internal sealed class InstallResult
{
    public bool Success { get; private set; }
    public string Message { get; private set; }

    private InstallResult(bool success, string message)
    {
        Success = success;
        Message = message;
    }

    public static InstallResult Ok(string message) { return new InstallResult(true, message); }
    public static InstallResult Fail(string message) { return new InstallResult(false, message); }
}

internal sealed class PavDPIStatus
{
    public bool Installed { get; set; }
    public bool ServiceRunning { get; set; }
    public bool EngineRunning { get; set; }
    public string EngineState { get; set; }
    public string ProfileName { get; set; }
    public string Detail { get; set; }
}

internal sealed class ConnectionProbeResult
{
    public string Host { get; set; }
    public string Addresses { get; set; }
    public bool DnsResolved { get; set; }
    public bool PoisonedAddress { get; set; }
    public bool Port443Open { get; set; }
    public int Milliseconds { get; set; }

    public override string ToString()
    {
        string dnsState = !DnsResolved ? "DNS HATA" : (PoisonedAddress ? "ENGEL IP'SI" : "DNS OK");
        string portState = Port443Open ? "443 OK" : "443 KAPALI";
        return Host + " | " + dnsState + " | " + portState + " | " + Milliseconds + " ms | " + Addresses;
    }
}

internal static class InstallerCore
{
    private const string ServiceName = "PavDPI";
    private const string PayloadResourceName = "PavDPI.Payload.zip";
    private const string PoisonedAddress = "195.175.254.2";
    private const string ExpectedEngineHash = "7ACDE0DC3D40E448B70B08D661F633A61DDC94E9292EE3DCF447C377162A455C";
    private static readonly string ProgramFilesDirectory = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
    private static readonly string InstallDirectory = Path.Combine(ProgramFilesDirectory, "PavDPI");
    private static readonly string DataDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "PavDPI");
    private static readonly string InstallerLogPath = Path.Combine(DataDirectory, "installer.log");
    private static readonly string StatePath = Path.Combine(DataDirectory, "state.txt");
    private static readonly object LogSync = new object();

    private static readonly string[] ProbeHosts =
    {
        "discord.com",
        "gateway.discord.gg",
        "www.roblox.com",
        "games.roblox.com",
        "thumbnails.roblox.com",
        "account.proton.me",
        "mail.proton.me"
    };

    public static InstallResult Install(PavDPIProfile requestedProfile, Action<string> progress)
    {
        string temporaryDirectory = null;
        string stagingDirectory = null;
        string backupDirectory = null;
        ServiceSnapshot previousPavDpi = null;

        try
        {
            EnsureAdministrator();
            if (requestedProfile == null) { throw new ArgumentNullException("requestedProfile"); }
            Directory.CreateDirectory(DataDirectory);
            previousPavDpi = WindowsServiceManager.Capture(ServiceName);
            Log("Install started. RequestedProfile=" + requestedProfile.Id);

            Report(progress, "Tek dosyalik paket cikartiliyor ve SHA-256 ile dogrulaniyor...");
            temporaryDirectory = Path.Combine(Path.GetTempPath(), "PavDPI-Install-" + Guid.NewGuid().ToString("N"));
            string extractedDirectory = Path.Combine(temporaryDirectory, "payload");
            Directory.CreateDirectory(extractedDirectory);
            ExtractEmbeddedPayload(extractedDirectory);
            VerifyPayload(extractedDirectory);

            stagingDirectory = Path.Combine(ProgramFilesDirectory, "PavDPI.new-" + Guid.NewGuid().ToString("N"));
            EnsureSafeChildPath(stagingDirectory, ProgramFilesDirectory);
            CopyDirectory(extractedDirectory, stagingDirectory);

            Report(progress, "Eski PavDPI hizmeti durduruluyor...");
            WindowsServiceManager.StopAndWait(ServiceName, TimeSpan.FromSeconds(20));
            KillInstalledEngines();

            if (Directory.Exists(InstallDirectory))
            {
                string backupRoot = Path.Combine(DataDirectory, "backups");
                Directory.CreateDirectory(backupRoot);
                backupDirectory = Path.Combine(backupRoot, "PavDPI-" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N").Substring(0, 6));
                EnsureSafeChildPath(backupDirectory, backupRoot);
                Directory.Move(InstallDirectory, backupDirectory);
                Log("Previous install moved to " + backupDirectory);
            }

            Directory.Move(stagingDirectory, InstallDirectory);
            stagingDirectory = null;
            string noticesPath = Path.Combine(InstallDirectory, "THIRD-PARTY-NOTICES.txt");
            if (File.Exists(noticesPath))
            {
                File.SetAttributes(noticesPath, File.GetAttributes(noticesPath) | FileAttributes.Hidden);
            }

            string serviceExecutable = Path.Combine(InstallDirectory, "PavDPI Service.exe");
            Report(progress, "Servis ve motor dosyalari kendi kendini test ediyor...");
            ProcessResult selfTest = RunProcess(serviceExecutable, "--self-test", InstallDirectory, 15000);
            if (selfTest.ExitCode != 0)
            {
                throw new InvalidOperationException("Servis oz-testi basarisiz: " + selfTest.Output);
            }

            Report(progress, "PavDPI Service Windows acilisina kaydediliyor...");
            WindowsServiceManager.InstallOrUpdate(
                ServiceName,
                "PavDPI Service",
                serviceExecutable,
                "PavDPI Service - penceresiz baglanti motoru");

            IList<PavDPIProfile> candidates = requestedProfile.IsAutomatic
                ? PavDPIProfile.AutomaticCandidates()
                : new List<PavDPIProfile> { requestedProfile };

            PavDPIProfile selectedProfile = null;
            IList<ConnectionProbeResult> lastResults = null;
            foreach (PavDPIProfile candidate in candidates)
            {
                Report(progress, "Bağlantı ayarları kontrol ediliyor…");
                ApplyProfile(candidate);
                DeleteStateFile();
                WindowsServiceManager.StopAndWait(ServiceName, TimeSpan.FromSeconds(15));
                WindowsServiceManager.StartAndWait(ServiceName, TimeSpan.FromSeconds(20));

                if (!WaitForStableEngine(TimeSpan.FromSeconds(35), TimeSpan.FromSeconds(6)))
                {
                    Report(progress, "Motor kararli calismadi; siradaki profil denenecek.");
                    continue;
                }

                FlushDns();
                lastResults = ProbeConnections();
                foreach (ConnectionProbeResult result in lastResults) { Report(progress, result.ToString()); }
                if (ConnectionsHealthy(lastResults))
                {
                    selectedProfile = candidate;
                    break;
                }
                Report(progress, "Bu profil tum baglanti kontrollerini gecemedi.");
            }

            if (selectedProfile == null)
            {
                string lastSummary = lastResults == null
                    ? "Baglanti testi baslatilamadi."
                    : String.Join("; ", lastResults.Select(delegate(ConnectionProbeResult result) { return result.ToString(); }).ToArray());
                throw new InvalidOperationException("Hicbir ayar Discord ve Roblox testlerini birlikte gecemedi. " + lastSummary);
            }

            CleanupOldBackups(0);
            FlushDns();
            Log("Install completed. SelectedProfile=" + selectedProfile.Id);
            return InstallResult.Ok(
                "PavDPI kuruldu ve doğrulandı.\r\n\r\nWindows açılışında otomatik olarak çalışacak.");
        }
        catch (Exception exception)
        {
            Log("Install failed: " + exception);
            try
            {
                Report(progress, "Kurulum basarisiz; onceki durum geri yukleniyor...");
                WindowsServiceManager.Delete(ServiceName);
                KillInstalledEngines();
                if (Directory.Exists(InstallDirectory)) { SafeDeleteDirectory(InstallDirectory, ProgramFilesDirectory); }
                if (!String.IsNullOrWhiteSpace(backupDirectory) && Directory.Exists(backupDirectory))
                {
                    Directory.Move(backupDirectory, InstallDirectory);
                    backupDirectory = null;
                }
                WindowsServiceManager.Restore(ServiceName, previousPavDpi);
                FlushDns();
                Log("Rollback completed.");
            }
            catch (Exception rollbackException)
            {
                Log("Rollback error: " + rollbackException);
            }
            return InstallResult.Fail("Kurulum tamamlanamadi: " + exception.Message + "\r\n\r\nGunluk: " + InstallerLogPath);
        }
        finally
        {
            TryDeleteDirectory(stagingDirectory, ProgramFilesDirectory);
            TryDeleteDirectory(temporaryDirectory, Path.GetTempPath());
        }
    }

    public static InstallResult Uninstall(Action<string> progress)
    {
        try
        {
            EnsureAdministrator();
            Log("Uninstall started.");
            Report(progress, "PavDPI Service durduruluyor...");
            WindowsServiceManager.Delete(ServiceName);
            KillInstalledEngines();
            if (Directory.Exists(InstallDirectory))
            {
                Report(progress, "Program dosyalari kaldiriliyor...");
                SafeDeleteDirectory(InstallDirectory, ProgramFilesDirectory);
            }
            FlushDns();
            Log("Uninstall completed.");
            return InstallResult.Ok("PavDPI kaldirildi. Teshis gunlukleri ProgramData\\PavDPI klasorunde korundu.");
        }
        catch (Exception exception)
        {
            Log("Uninstall failed: " + exception);
            return InstallResult.Fail("Kaldirma tamamlanamadi: " + exception.Message + "\r\n\r\nGunluk: " + InstallerLogPath);
        }
    }

    public static PavDPIStatus QueryStatus()
    {
        PavDPIStatus status = new PavDPIStatus();
        status.Installed = WindowsServiceManager.Exists(ServiceName) && File.Exists(Path.Combine(InstallDirectory, "PavDPI Service.exe"));
        status.ServiceRunning = WindowsServiceManager.IsRunning(ServiceName);
        status.EngineState = "UNKNOWN";
        status.ProfileName = ReadTextFile(Path.Combine(InstallDirectory, "config", "profile.name"), "-");
        status.Detail = "Canli durum dosyasi bulunamadi.";

        Dictionary<string, string> state = ReadKeyValueFile(StatePath);
        if (state.ContainsKey("status")) { status.EngineState = state["status"]; }
        if (state.ContainsKey("profile")) { status.ProfileName = state["profile"]; }
        if (state.ContainsKey("detail")) { status.Detail = state["detail"]; }
        int processId;
        Int32.TryParse(state.ContainsKey("pid") ? state["pid"] : "0", out processId);
        status.EngineRunning = status.ServiceRunning && String.Equals(status.EngineState, "ENGINE_RUNNING", StringComparison.OrdinalIgnoreCase) && IsProcessAlive(processId);
        return status;
    }

    public static bool RequiresUpgrade()
    {
        if (!QueryStatus().Installed) { return true; }
        string installedProfileName = ReadTextFile(Path.Combine(InstallDirectory, "config", "profile.name"), String.Empty);
        if (!String.Equals(installedProfileName, "Otomatik", StringComparison.OrdinalIgnoreCase)) { return true; }
        string installedEngine = Path.Combine(InstallDirectory, "engine", "PavDPI Engine.exe");
        if (!File.Exists(installedEngine)) { return true; }
        try { return !String.Equals(ComputeSha256(installedEngine), ExpectedEngineHash, StringComparison.OrdinalIgnoreCase); }
        catch { return true; }
    }

    public static IList<ConnectionProbeResult> ProbeConnections()
    {
        List<ConnectionProbeResult> results = new List<ConnectionProbeResult>();
        foreach (string host in ProbeHosts)
        {
            Stopwatch stopwatch = Stopwatch.StartNew();
            ConnectionProbeResult result = new ConnectionProbeResult();
            result.Host = host;
            try
            {
                IPAddress[] addresses = Dns.GetHostAddresses(host);
                result.DnsResolved = addresses.Length > 0;
                result.Addresses = String.Join(",", addresses.Select(delegate(IPAddress address) { return address.ToString(); }).ToArray());
                result.PoisonedAddress = addresses.Any(delegate(IPAddress address) { return address.ToString() == PoisonedAddress; });
                result.Port443Open = !result.PoisonedAddress && TryConnect(addresses, 443, 4500);
            }
            catch (Exception exception)
            {
                result.Addresses = "HATA: " + exception.Message;
                result.DnsResolved = false;
                result.PoisonedAddress = false;
                result.Port443Open = false;
            }
            stopwatch.Stop();
            result.Milliseconds = (int)stopwatch.ElapsedMilliseconds;
            results.Add(result);
        }
        return results;
    }

    public static bool ConnectionsHealthy(IList<ConnectionProbeResult> results)
    {
        if (results == null || results.Count != ProbeHosts.Length) { return false; }
        return results.All(delegate(ConnectionProbeResult result)
        {
            return result.DnsResolved && !result.PoisonedAddress && result.Port443Open;
        });
    }

    public static string GetInstallerLogPath() { return InstallerLogPath; }

    private static void EnsureAdministrator()
    {
        using (WindowsIdentity identity = WindowsIdentity.GetCurrent())
        {
            WindowsPrincipal principal = new WindowsPrincipal(identity);
            if (!principal.IsInRole(WindowsBuiltInRole.Administrator))
            {
                throw new UnauthorizedAccessException("PavDPI kurulumu icin Windows yonetici onayi gerekir.");
            }
        }
    }

    private static void ApplyProfile(PavDPIProfile profile)
    {
        if (profile == null || profile.IsAutomatic || String.IsNullOrWhiteSpace(profile.Arguments))
        {
            throw new InvalidOperationException("Gecersiz PavDPI profili.");
        }
        if (profile.Arguments.Contains("--set-ttl") && !profile.Arguments.Contains("--blacklist"))
        {
            throw new InvalidOperationException("Guvenlik denetimi: sabit TTL yalnizca hedef listesiyle kullanilabilir.");
        }
        string configDirectory = Path.Combine(InstallDirectory, "config");
        Directory.CreateDirectory(configDirectory);
        File.WriteAllText(Path.Combine(configDirectory, "profile.args"), profile.Arguments + Environment.NewLine, new UTF8Encoding(false));
        File.WriteAllText(Path.Combine(configDirectory, "profile.name"), profile.DisplayName + Environment.NewLine, new UTF8Encoding(false));
    }

    private static void ExtractEmbeddedPayload(string destinationDirectory)
    {
        using (Stream payload = Assembly.GetExecutingAssembly().GetManifestResourceStream(PayloadResourceName))
        {
            if (payload == null) { throw new InvalidOperationException("Gomulu PavDPI paketi bulunamadi."); }
            using (ZipArchive archive = new ZipArchive(payload, ZipArchiveMode.Read, false))
            {
                foreach (ZipArchiveEntry entry in archive.Entries)
                {
                    string normalizedName = entry.FullName.Replace('/', Path.DirectorySeparatorChar);
                    if (String.IsNullOrWhiteSpace(normalizedName)) { continue; }
                    string destinationPath = SafeCombine(destinationDirectory, normalizedName);
                    if (entry.FullName.EndsWith("/", StringComparison.Ordinal))
                    {
                        Directory.CreateDirectory(destinationPath);
                        continue;
                    }
                    Directory.CreateDirectory(Path.GetDirectoryName(destinationPath));
                    using (Stream input = entry.Open())
                    using (FileStream output = new FileStream(destinationPath, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                    {
                        input.CopyTo(output);
                    }
                }
            }
        }
    }

    private static void VerifyPayload(string payloadDirectory)
    {
        string manifestPath = Path.Combine(payloadDirectory, "manifest.sha256");
        if (!File.Exists(manifestPath)) { throw new FileNotFoundException("Paket butunluk listesi bulunamadi.", manifestPath); }

        string[] required =
        {
            "PavDPI Service.exe",
            "engine\\PavDPI Engine.exe",
            "engine\\WinDivert.dll",
            "engine\\WinDivert64.sys",
            "config\\profile.args",
            "config\\profile.name",
            "config\\targets.txt",
            "THIRD-PARTY-NOTICES.txt"
        };
        HashSet<string> manifestFiles = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (string line in File.ReadAllLines(manifestPath, Encoding.UTF8))
        {
            if (String.IsNullOrWhiteSpace(line)) { continue; }
            int separator = line.IndexOf("  ", StringComparison.Ordinal);
            if (separator != 64) { throw new InvalidDataException("Gecersiz butunluk satiri: " + line); }
            string expectedHash = line.Substring(0, 64).ToUpperInvariant();
            string relativePath = line.Substring(separator + 2).Replace('/', Path.DirectorySeparatorChar);
            if (!manifestFiles.Add(relativePath)) { throw new InvalidDataException("Tekrarlanan paket yolu: " + relativePath); }
            string fullPath = SafeCombine(payloadDirectory, relativePath);
            if (!File.Exists(fullPath)) { throw new FileNotFoundException("Paket dosyasi eksik: " + relativePath, fullPath); }
            if (!String.Equals(expectedHash, ComputeSha256(fullPath), StringComparison.OrdinalIgnoreCase))
            {
                throw new InvalidDataException("Paket dosyasi dogrulanamadi: " + relativePath);
            }
        }

        foreach (string relativePath in required)
        {
            if (!manifestFiles.Contains(relativePath)) { throw new InvalidDataException("Zorunlu paket dosyasi manifestte yok: " + relativePath); }
        }
        foreach (string file in Directory.GetFiles(payloadDirectory, "*", SearchOption.AllDirectories))
        {
            string relative = file.Substring(payloadDirectory.Length).TrimStart(Path.DirectorySeparatorChar);
            if (!String.Equals(relative, "manifest.sha256", StringComparison.OrdinalIgnoreCase) && !manifestFiles.Contains(relative))
            {
                throw new InvalidDataException("Manifest disi paket dosyasi: " + relative);
            }
        }
    }

    private static bool WaitForStableEngine(TimeSpan maximumWait, TimeSpan requiredStableTime)
    {
        DateTime deadline = DateTime.UtcNow + maximumWait;
        DateTime? stableSince = null;
        int stableProcessId = 0;
        while (DateTime.UtcNow < deadline)
        {
            if (!WindowsServiceManager.IsRunning(ServiceName))
            {
                stableSince = null;
                Thread.Sleep(500);
                continue;
            }
            Dictionary<string, string> state = ReadKeyValueFile(StatePath);
            string stateValue = state.ContainsKey("status") ? state["status"] : String.Empty;
            int processId;
            Int32.TryParse(state.ContainsKey("pid") ? state["pid"] : "0", out processId);
            if (String.Equals(stateValue, "ENGINE_RUNNING", StringComparison.OrdinalIgnoreCase) && IsProcessAlive(processId))
            {
                if (!stableSince.HasValue || stableProcessId != processId)
                {
                    stableSince = DateTime.UtcNow;
                    stableProcessId = processId;
                }
                if (DateTime.UtcNow - stableSince.Value >= requiredStableTime) { return true; }
            }
            else
            {
                stableSince = null;
                stableProcessId = 0;
            }
            Thread.Sleep(500);
        }
        return false;
    }

    private static bool IsProcessAlive(int processId)
    {
        if (processId <= 0) { return false; }
        try
        {
            using (Process process = Process.GetProcessById(processId)) { return !process.HasExited; }
        }
        catch { return false; }
    }

    private static bool TryConnect(IPAddress[] addresses, int port, int timeoutMilliseconds)
    {
        if (addresses == null || addresses.Length == 0) { return false; }
        DateTime deadline = DateTime.UtcNow.AddMilliseconds(timeoutMilliseconds);
        foreach (IPAddress address in addresses)
        {
            int remaining = (int)Math.Max(0, (deadline - DateTime.UtcNow).TotalMilliseconds);
            if (remaining <= 0) { break; }
            int attemptsLeft = Math.Max(1, addresses.Length);
            int attemptTimeout = Math.Max(350, remaining / attemptsLeft);
            using (Socket socket = new Socket(address.AddressFamily, SocketType.Stream, ProtocolType.Tcp))
            {
                IAsyncResult pending = null;
                try
                {
                    pending = socket.BeginConnect(new IPEndPoint(address, port), null, null);
                    if (!pending.AsyncWaitHandle.WaitOne(attemptTimeout)) { continue; }
                    socket.EndConnect(pending);
                    if (socket.Connected) { return true; }
                }
                catch { }
                finally { if (pending != null) { pending.AsyncWaitHandle.Close(); } }
            }
        }
        return false;
    }

    private static void KillInstalledEngines()
    {
        string installPrefix = Path.GetFullPath(InstallDirectory).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        foreach (string processName in new string[] { "PavDPI Engine", "pavdpi" })
        {
            foreach (Process process in Process.GetProcessesByName(processName))
            {
                try
                {
                    string executablePath = process.MainModule.FileName;
                    if (!Path.GetFullPath(executablePath).StartsWith(installPrefix, StringComparison.OrdinalIgnoreCase)) { continue; }
                    Log("Stopping installed engine PID=" + process.Id + " Path=" + executablePath);
                    process.Kill();
                    process.WaitForExit(5000);
                }
                catch (Exception exception) { Log("Installed engine stop error PID=" + process.Id + ": " + exception.Message); }
                finally { process.Dispose(); }
            }
        }
    }

    private static void FlushDns()
    {
        try { RunProcess(Path.Combine(Environment.SystemDirectory, "ipconfig.exe"), "/flushdns", Environment.SystemDirectory, 10000); }
        catch (Exception exception) { Log("DNS flush warning: " + exception.Message); }
    }

    private static ProcessResult RunProcess(string executable, string arguments, string workingDirectory, int timeoutMilliseconds)
    {
        ProcessStartInfo startInfo = new ProcessStartInfo();
        startInfo.FileName = executable;
        startInfo.Arguments = arguments;
        startInfo.WorkingDirectory = workingDirectory;
        startInfo.UseShellExecute = false;
        startInfo.CreateNoWindow = true;
        startInfo.RedirectStandardOutput = true;
        startInfo.RedirectStandardError = true;
        using (Process process = Process.Start(startInfo))
        {
            if (process == null) { throw new InvalidOperationException("Komut baslatilamadi: " + executable); }
            string output = process.StandardOutput.ReadToEnd() + process.StandardError.ReadToEnd();
            if (!process.WaitForExit(timeoutMilliseconds))
            {
                try { process.Kill(); } catch { }
                throw new TimeoutException("Komut zaman asimina ugradi: " + executable);
            }
            Log("Command: " + Path.GetFileName(executable) + " " + arguments + " Exit=" + process.ExitCode + " Output=" + CleanLine(output));
            return new ProcessResult(process.ExitCode, output.Trim());
        }
    }

    private static void CopyDirectory(string sourceDirectory, string destinationDirectory)
    {
        Directory.CreateDirectory(destinationDirectory);
        foreach (string sourceFile in Directory.GetFiles(sourceDirectory))
        {
            File.Copy(sourceFile, Path.Combine(destinationDirectory, Path.GetFileName(sourceFile)), true);
        }
        foreach (string sourceChild in Directory.GetDirectories(sourceDirectory))
        {
            CopyDirectory(sourceChild, Path.Combine(destinationDirectory, Path.GetFileName(sourceChild)));
        }
    }

    private static string SafeCombine(string root, string relativePath)
    {
        if (Path.IsPathRooted(relativePath) || relativePath.IndexOf(':') >= 0)
        {
            throw new InvalidDataException("Paket yolu guvenli degil: " + relativePath);
        }
        string fullRoot = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        string fullPath = Path.GetFullPath(Path.Combine(root, relativePath));
        if (!fullPath.StartsWith(fullRoot, StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidDataException("Paket yolu guvenli degil: " + relativePath);
        }
        return fullPath;
    }

    private static void EnsureSafeChildPath(string path, string parent)
    {
        string fullParent = Path.GetFullPath(parent).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        string fullPath = Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar);
        if (!fullPath.StartsWith(fullParent, StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("Guvenli olmayan dosya hedefi: " + fullPath);
        }
    }

    private static void SafeDeleteDirectory(string path, string allowedParent)
    {
        EnsureSafeChildPath(path, allowedParent);
        if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
        {
            throw new InvalidOperationException("Yeniden yonlendirilmis klasor silinmedi: " + path);
        }
        Directory.Delete(path, true);
    }

    private static void TryDeleteDirectory(string path, string allowedParent)
    {
        if (String.IsNullOrWhiteSpace(path) || !Directory.Exists(path)) { return; }
        try { SafeDeleteDirectory(path, allowedParent); } catch (Exception exception) { Log("Temporary cleanup warning: " + exception.Message); }
    }

    private static string ComputeSha256(string path)
    {
        using (SHA256 sha256 = SHA256.Create())
        using (FileStream stream = File.OpenRead(path))
        {
            return BitConverter.ToString(sha256.ComputeHash(stream)).Replace("-", String.Empty);
        }
    }

    private static Dictionary<string, string> ReadKeyValueFile(string path)
    {
        Dictionary<string, string> values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        try
        {
            if (!File.Exists(path)) { return values; }
            foreach (string line in File.ReadAllLines(path, Encoding.UTF8))
            {
                int separator = line.IndexOf('=');
                if (separator > 0) { values[line.Substring(0, separator).Trim()] = line.Substring(separator + 1).Trim(); }
            }
        }
        catch { }
        return values;
    }

    private static string ReadTextFile(string path, string fallback)
    {
        try { return File.Exists(path) ? CleanLine(File.ReadAllText(path, Encoding.UTF8)).Trim() : fallback; }
        catch { return fallback; }
    }

    private static void DeleteStateFile()
    {
        try { if (File.Exists(StatePath)) { File.Delete(StatePath); } } catch { }
    }

    private static void CleanupOldBackups(int keepCount)
    {
        string backupRoot = Path.Combine(DataDirectory, "backups");
        if (!Directory.Exists(backupRoot)) { return; }
        DirectoryInfo[] backups = new DirectoryInfo(backupRoot).GetDirectories("PavDPI-*")
            .OrderByDescending(delegate(DirectoryInfo directory) { return directory.CreationTimeUtc; })
            .ToArray();
        for (int index = keepCount; index < backups.Length; index++)
        {
            try { SafeDeleteDirectory(backups[index].FullName, backupRoot); }
            catch (Exception exception) { Log("Backup cleanup warning: " + exception.Message); }
        }
    }

    private static void Report(Action<string> progress, string message)
    {
        Log(message);
        if (progress != null) { progress(message); }
    }

    private static string CleanLine(string value)
    {
        return value == null ? String.Empty : value.Replace("\r", " ").Replace("\n", " ");
    }

    private static void Log(string message)
    {
        lock (LogSync)
        {
            try
            {
                Directory.CreateDirectory(DataDirectory);
                File.AppendAllText(InstallerLogPath, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + " | " + message + Environment.NewLine, new UTF8Encoding(false));
            }
            catch { }
        }
    }

    private sealed class ProcessResult
    {
        public int ExitCode { get; private set; }
        public string Output { get; private set; }

        public ProcessResult(int exitCode, string output)
        {
            ExitCode = exitCode;
            Output = output;
        }
    }
}
