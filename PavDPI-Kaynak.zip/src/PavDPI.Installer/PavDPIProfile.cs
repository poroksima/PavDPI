using System;
using System.Collections.Generic;
using System.Linq;

internal sealed class PavDPIProfile
{
    private const string DnsArguments = "--dns-addr 77.88.8.8 --dns-port 1253 --dnsv6-addr 2a02:6b8::feed:0ff --dnsv6-port 1253";
    private const string TargetArguments = "--blacklist \"..\\config\\targets.txt\"";

    public string Id { get; private set; }
    public string DisplayName { get; private set; }
    public string Description { get; private set; }
    public string Arguments { get; private set; }
    public bool IsAutomatic { get; private set; }

    private PavDPIProfile(string id, string displayName, string description, string arguments, bool isAutomatic)
    {
        Id = id;
        DisplayName = displayName;
        Description = description;
        Arguments = arguments;
        IsAutomatic = isAutomatic;
    }

    public override string ToString()
    {
        return DisplayName;
    }

    public static IList<PavDPIProfile> All()
    {
        return new List<PavDPIProfile>
        {
            new PavDPIProfile(
                "auto",
                "Otomatik",
                "Discord ve Roblox'u dener; calisan en guvenli ayari kendisi secer.",
                String.Empty,
                true),
            Targeted(),
            Balanced(),
            Compatible(),
            Alternative()
        };
    }

    public static IList<PavDPIProfile> AutomaticCandidates()
    {
        return new List<PavDPIProfile> { Targeted(), Balanced(), Compatible(), Alternative() };
    }

    public static PavDPIProfile Find(string id)
    {
        return All().FirstOrDefault(delegate(PavDPIProfile profile)
        {
            return String.Equals(profile.Id, id, StringComparison.OrdinalIgnoreCase);
        });
    }

    private static PavDPIProfile Targeted()
    {
        return new PavDPIProfile(
            "turkey-targeted",
            "Otomatik",
            "TTL 7 yalnizca hedef alan adlarinda kullanilir; genel web trafigi etkilenmez.",
            "-f 2 -e 2 --reverse-frag --max-payload --set-ttl 7 " + TargetArguments + " " + DnsArguments,
            false);
    }

    private static PavDPIProfile Balanced()
    {
        return new PavDPIProfile(
            "turkey-balanced",
            "Otomatik",
            "Modern mod 5 ve otomatik TTL kullanir; yalnizca hedef alan adlarina uygulanir.",
            "-5 " + TargetArguments + " " + DnsArguments,
            false);
    }

    private static PavDPIProfile Compatible()
    {
        return new PavDPIProfile(
            "turkey-compatible",
            "Otomatik",
            "Eski ama uyumlu mod 1; yalnizca hedef alan adlarina uygulanir.",
            "-1 " + TargetArguments + " " + DnsArguments,
            false);
    }

    private static PavDPIProfile Alternative()
    {
        return new PavDPIProfile(
            "turkey-alternative",
            "Otomatik",
            "Alternatif modern mod; yalnizca hedef alan adlarina uygulanir.",
            "-6 " + TargetArguments + " " + DnsArguments,
            false);
    }
}
