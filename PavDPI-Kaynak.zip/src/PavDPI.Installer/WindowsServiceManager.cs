using Microsoft.Win32;
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Threading;

internal sealed class ServiceSnapshot
{
    public bool Exists { get; set; }
    public bool WasRunning { get; set; }
    public string BinaryPath { get; set; }
    public string DisplayName { get; set; }
    public string Description { get; set; }
    public string[] Dependencies { get; set; }
    public uint StartType { get; set; }
}

internal static class WindowsServiceManager
{
    private const uint ScManagerConnect = 0x0001;
    private const uint ScManagerCreateService = 0x0002;
    private const uint ServiceAllAccess = 0xF01FF;
    private const uint ServiceWin32OwnProcess = 0x00000010;
    private const uint ServiceAutoStart = 0x00000002;
    private const uint ServiceErrorNormal = 0x00000001;
    private const uint ServiceNoChange = 0xFFFFFFFF;
    private const int ErrorServiceDoesNotExist = 1060;
    private const int ServiceConfigDescription = 1;
    private const int ServiceConfigFailureActions = 2;
    private const int ServiceConfigFailureActionsFlag = 4;
    private const int ScActionRestart = 1;

    public static string QuoteBinaryPath(string executablePath)
    {
        if (String.IsNullOrWhiteSpace(executablePath))
        {
            throw new ArgumentException("Service executable path is empty.", "executablePath");
        }
        string fullPath = System.IO.Path.GetFullPath(executablePath);
        return "\"" + fullPath.Replace("\"", String.Empty) + "\"";
    }

    public static ServiceSnapshot Capture(string serviceName)
    {
        ServiceSnapshot snapshot = new ServiceSnapshot();
        snapshot.Exists = Exists(serviceName);
        snapshot.WasRunning = snapshot.Exists && IsRunning(serviceName);
        snapshot.StartType = ServiceAutoStart;
        snapshot.Dependencies = new string[0];
        if (!snapshot.Exists) { return snapshot; }

        using (RegistryKey key = Registry.LocalMachine.OpenSubKey("SYSTEM\\CurrentControlSet\\Services\\" + serviceName, false))
        {
            if (key == null) { return snapshot; }
            snapshot.BinaryPath = Convert.ToString(key.GetValue("ImagePath", String.Empty));
            snapshot.DisplayName = Convert.ToString(key.GetValue("DisplayName", serviceName));
            snapshot.Description = Convert.ToString(key.GetValue("Description", String.Empty));
            snapshot.StartType = Convert.ToUInt32(key.GetValue("Start", (int)ServiceAutoStart));
            object dependencies = key.GetValue("DependOnService", new string[0]);
            snapshot.Dependencies = dependencies as string[] ?? new string[0];
        }
        return snapshot;
    }

    public static void InstallOrUpdate(string serviceName, string displayName, string executablePath, string description)
    {
        IntPtr manager = OpenManager();
        try
        {
            string binaryPath = QuoteBinaryPath(executablePath);
            string dependencies = BuildMultiString(new string[] { "BFE" });
            IntPtr service = OpenService(manager, serviceName, ServiceAllAccess);
            if (service == IntPtr.Zero)
            {
                int error = Marshal.GetLastWin32Error();
                if (error != ErrorServiceDoesNotExist) { throw new Win32Exception(error, "PavDPI service could not be opened."); }
                service = CreateService(
                    manager,
                    serviceName,
                    displayName,
                    ServiceAllAccess,
                    ServiceWin32OwnProcess,
                    ServiceAutoStart,
                    ServiceErrorNormal,
                    binaryPath,
                    null,
                    IntPtr.Zero,
                    dependencies,
                    null,
                    null);
                if (service == IntPtr.Zero) { ThrowLastError("PavDPI service could not be created."); }
            }
            else
            {
                if (!ChangeServiceConfig(
                    service,
                    ServiceNoChange,
                    ServiceAutoStart,
                    ServiceNoChange,
                    binaryPath,
                    null,
                    IntPtr.Zero,
                    dependencies,
                    null,
                    null,
                    displayName))
                {
                    ThrowLastError("PavDPI service configuration could not be updated.");
                }
            }

            try
            {
                ConfigureDescription(service, description);
                ConfigureRecovery(service);
            }
            finally { CloseServiceHandle(service); }
        }
        finally { CloseServiceHandle(manager); }
    }

    public static void Restore(string serviceName, ServiceSnapshot snapshot)
    {
        Delete(serviceName);
        if (snapshot == null || !snapshot.Exists) { return; }
        if (String.IsNullOrWhiteSpace(snapshot.BinaryPath))
        {
            throw new InvalidOperationException("Previous service path was empty; rollback cannot recreate it.");
        }

        IntPtr manager = OpenManager();
        try
        {
            IntPtr service = CreateService(
                manager,
                serviceName,
                String.IsNullOrWhiteSpace(snapshot.DisplayName) ? serviceName : snapshot.DisplayName,
                ServiceAllAccess,
                ServiceWin32OwnProcess,
                snapshot.StartType,
                ServiceErrorNormal,
                snapshot.BinaryPath,
                null,
                IntPtr.Zero,
                BuildMultiString(snapshot.Dependencies),
                null,
                null);
            if (service == IntPtr.Zero) { ThrowLastError("Previous PavDPI service could not be restored."); }
            try
            {
                if (!String.IsNullOrWhiteSpace(snapshot.Description)) { ConfigureDescription(service, snapshot.Description); }
            }
            finally { CloseServiceHandle(service); }
        }
        finally { CloseServiceHandle(manager); }

        if (snapshot.WasRunning) { StartAndWait(serviceName, TimeSpan.FromSeconds(20)); }
    }

    public static void StartAndWait(string serviceName, TimeSpan timeout)
    {
        using (ServiceController controller = new ServiceController(serviceName))
        {
            controller.Refresh();
            if (controller.Status == ServiceControllerStatus.Running) { return; }
            if (controller.Status == ServiceControllerStatus.StopPending)
            {
                controller.WaitForStatus(ServiceControllerStatus.Stopped, timeout);
                controller.Refresh();
            }
            controller.Start();
            controller.WaitForStatus(ServiceControllerStatus.Running, timeout);
        }
    }

    public static void StopAndWait(string serviceName, TimeSpan timeout)
    {
        if (!Exists(serviceName)) { return; }
        using (ServiceController controller = new ServiceController(serviceName))
        {
            controller.Refresh();
            if (controller.Status == ServiceControllerStatus.Stopped) { return; }
            if (controller.Status != ServiceControllerStatus.StopPending && controller.CanStop) { controller.Stop(); }
            controller.WaitForStatus(ServiceControllerStatus.Stopped, timeout);
        }
    }

    public static void Delete(string serviceName)
    {
        if (!Exists(serviceName)) { return; }
        try { StopAndWait(serviceName, TimeSpan.FromSeconds(20)); } catch { }

        IntPtr manager = OpenManager();
        try
        {
            IntPtr service = OpenService(manager, serviceName, ServiceAllAccess);
            if (service == IntPtr.Zero)
            {
                int error = Marshal.GetLastWin32Error();
                if (error == ErrorServiceDoesNotExist) { return; }
                throw new Win32Exception(error);
            }
            try
            {
                if (!DeleteService(service))
                {
                    int error = Marshal.GetLastWin32Error();
                    if (error != 1072) { throw new Win32Exception(error, "Service could not be deleted."); }
                }
            }
            finally { CloseServiceHandle(service); }
        }
        finally { CloseServiceHandle(manager); }

        DateTime deadline = DateTime.UtcNow.AddSeconds(15);
        while (DateTime.UtcNow < deadline && Exists(serviceName)) { Thread.Sleep(250); }
    }

    public static bool Exists(string serviceName)
    {
        try
        {
            using (ServiceController controller = new ServiceController(serviceName))
            {
                ServiceControllerStatus ignored = controller.Status;
                return true;
            }
        }
        catch { return false; }
    }

    public static bool IsRunning(string serviceName)
    {
        try
        {
            using (ServiceController controller = new ServiceController(serviceName))
            {
                return controller.Status == ServiceControllerStatus.Running;
            }
        }
        catch { return false; }
    }

    private static IntPtr OpenManager()
    {
        IntPtr manager = OpenSCManager(null, null, ScManagerConnect | ScManagerCreateService);
        if (manager == IntPtr.Zero) { ThrowLastError("Windows Service Manager could not be opened."); }
        return manager;
    }

    private static void ConfigureDescription(IntPtr service, string description)
    {
        SERVICE_DESCRIPTION value = new SERVICE_DESCRIPTION();
        value.Description = description;
        if (!ChangeServiceConfig2Description(service, ServiceConfigDescription, ref value))
        {
            ThrowLastError("Service description could not be configured.");
        }
    }

    private static void ConfigureRecovery(IntPtr service)
    {
        SC_ACTION[] actions =
        {
            new SC_ACTION { Type = ScActionRestart, Delay = 5000 },
            new SC_ACTION { Type = ScActionRestart, Delay = 15000 },
            new SC_ACTION { Type = ScActionRestart, Delay = 60000 }
        };
        int actionSize = Marshal.SizeOf(typeof(SC_ACTION));
        IntPtr actionPointer = Marshal.AllocHGlobal(actionSize * actions.Length);
        try
        {
            for (int index = 0; index < actions.Length; index++)
            {
                Marshal.StructureToPtr(actions[index], IntPtr.Add(actionPointer, index * actionSize), false);
            }
            SERVICE_FAILURE_ACTIONS value = new SERVICE_FAILURE_ACTIONS();
            value.ResetPeriod = 86400;
            value.ActionCount = (uint)actions.Length;
            value.Actions = actionPointer;
            if (!ChangeServiceConfig2FailureActions(service, ServiceConfigFailureActions, ref value))
            {
                ThrowLastError("Service recovery actions could not be configured.");
            }
            SERVICE_FAILURE_ACTIONS_FLAG flag = new SERVICE_FAILURE_ACTIONS_FLAG();
            flag.Enabled = 1;
            if (!ChangeServiceConfig2FailureFlag(service, ServiceConfigFailureActionsFlag, ref flag))
            {
                ThrowLastError("Service failure flag could not be configured.");
            }
        }
        finally { Marshal.FreeHGlobal(actionPointer); }
    }

    private static string BuildMultiString(string[] values)
    {
        if (values == null || values.Length == 0) { return null; }
        return String.Join("\0", values) + "\0\0";
    }

    private static void ThrowLastError(string message)
    {
        throw new Win32Exception(Marshal.GetLastWin32Error(), message);
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct SERVICE_DESCRIPTION { [MarshalAs(UnmanagedType.LPWStr)] public string Description; }

    [StructLayout(LayoutKind.Sequential)]
    private struct SC_ACTION { public int Type; public uint Delay; }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct SERVICE_FAILURE_ACTIONS
    {
        public uint ResetPeriod;
        public string RebootMessage;
        public string Command;
        public uint ActionCount;
        public IntPtr Actions;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct SERVICE_FAILURE_ACTIONS_FLAG { public int Enabled; }

    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr OpenSCManager(string machineName, string databaseName, uint desiredAccess);

    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr OpenService(IntPtr manager, string serviceName, uint desiredAccess);

    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr CreateService(
        IntPtr manager,
        string serviceName,
        string displayName,
        uint desiredAccess,
        uint serviceType,
        uint startType,
        uint errorControl,
        string binaryPath,
        string loadOrderGroup,
        IntPtr tagId,
        string dependencies,
        string accountName,
        string password);

    [DllImport("advapi32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool ChangeServiceConfig(
        IntPtr service,
        uint serviceType,
        uint startType,
        uint errorControl,
        string binaryPath,
        string loadOrderGroup,
        IntPtr tagId,
        string dependencies,
        string accountName,
        string password,
        string displayName);

    [DllImport("advapi32.dll", EntryPoint = "ChangeServiceConfig2W", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool ChangeServiceConfig2Description(IntPtr service, int informationLevel, ref SERVICE_DESCRIPTION information);

    [DllImport("advapi32.dll", EntryPoint = "ChangeServiceConfig2W", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern bool ChangeServiceConfig2FailureActions(IntPtr service, int informationLevel, ref SERVICE_FAILURE_ACTIONS information);

    [DllImport("advapi32.dll", EntryPoint = "ChangeServiceConfig2W", SetLastError = true)]
    private static extern bool ChangeServiceConfig2FailureFlag(IntPtr service, int informationLevel, ref SERVICE_FAILURE_ACTIONS_FLAG information);

    [DllImport("advapi32.dll", SetLastError = true)]
    private static extern bool DeleteService(IntPtr service);

    [DllImport("advapi32.dll")]
    private static extern bool CloseServiceHandle(IntPtr service);
}
