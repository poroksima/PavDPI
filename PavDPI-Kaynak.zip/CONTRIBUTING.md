# Contributing

1. Keep the project buildable with the Windows .NET Framework compiler and PowerShell 5.1.
2. Do not add telemetry, ads, toast notifications, process hiding, code injection, or silent network downloads.
3. Never enable fixed TTL globally; it must be paired with the checked-in target list.
4. Preserve all third-party license files and pinned binary hashes.
5. Run `tests\run-all.ps1` before submitting a change.
6. Explain any connection-rule change and its compatibility trade-offs in the pull request.
