# Security Policy

## Supported version

Only the latest PavDPI release is supported.

## Reporting

Do not publish secrets, personal logs, IP addresses, or account data in a public issue. Report the PavDPI version, Windows version, the relevant redacted log lines, and reproducible steps.

## Trust model

PavDPI requires administrator access because it installs a Windows service and the WinDivert driver. It does not bypass UAC, hide processes, inject into other applications, show advertisements, collect telemetry, or download executable updates. The release payload is embedded in the installer and verified against a SHA-256 manifest before installation.

Third-party binaries remain subject to their own security policies and licenses.
