[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$pavRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$pavTestRoot = Join-Path $pavRoot 'build\service-supervisor-test'
if (Test-Path -LiteralPath $pavTestRoot) { Remove-Item -LiteralPath $pavTestRoot -Recurse -Force }
$pavEngineRoot = Join-Path $pavTestRoot 'engine'
$pavConfigRoot = Join-Path $pavTestRoot 'config'
$pavDataRoot = Join-Path $pavTestRoot 'data'
New-Item -ItemType Directory -Path $pavEngineRoot -Force | Out-Null
New-Item -ItemType Directory -Path $pavConfigRoot -Force | Out-Null
New-Item -ItemType Directory -Path $pavDataRoot -Force | Out-Null

$pavCsc = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$pavServiceExe = Join-Path $pavTestRoot 'PavDPI Service.exe'
$pavEngineExe = Join-Path $pavEngineRoot 'PavDPI Engine.exe'
& $pavCsc /nologo /target:exe /platform:x64 /optimize+ /reference:System.ServiceProcess.dll `
    "/out:$pavServiceExe" (Join-Path $pavRoot 'src\PavDPI.Service\PavDPI.Service.cs')
if ($LASTEXITCODE -ne 0) { throw "Service test build failed: $LASTEXITCODE" }
& $pavCsc /nologo /target:exe /platform:x64 /optimize+ `
    "/out:$pavEngineExe" (Join-Path $pavRoot 'tests\TestEngine.cs')
if ($LASTEXITCODE -ne 0) { throw "Engine test build failed: $LASTEXITCODE" }

[System.IO.File]::WriteAllBytes((Join-Path $pavEngineRoot 'WinDivert.dll'), [byte[]](1,2,3))
[System.IO.File]::WriteAllBytes((Join-Path $pavEngineRoot 'WinDivert64.sys'), [byte[]](4,5,6))
[System.IO.File]::WriteAllText((Join-Path $pavConfigRoot 'profile.args'), "--test`r`n")
[System.IO.File]::WriteAllText((Join-Path $pavConfigRoot 'profile.name'), "Supervisor test`r`n")
[System.IO.File]::WriteAllText((Join-Path $pavConfigRoot 'targets.txt'), "discord.com`r`n")

$pavPreviousData = $env:PAVDPI_DATA_DIR
try {
    $env:PAVDPI_DATA_DIR = $pavDataRoot
    & $pavServiceExe --run-for 17
    if ($LASTEXITCODE -ne 0) { throw "Supervisor run failed: $LASTEXITCODE" }
}
finally { $env:PAVDPI_DATA_DIR = $pavPreviousData }

$pavLog = Get-Content -LiteralPath (Join-Path $pavDataRoot 'logs\PavDPI.log') -Raw
$pavState = Get-Content -LiteralPath (Join-Path $pavDataRoot 'state.txt') -Raw
$pavStarts = ([regex]::Matches($pavLog, '\| Engine started\. PID=')).Count
$pavExits = ([regex]::Matches($pavLog, '\| Engine exited unexpectedly\.')).Count
if ($pavStarts -lt 2) { throw "Supervisor did not restart engine. Starts=$pavStarts" }
if ($pavExits -lt 1) { throw "Supervisor did not log engine exit. Exits=$pavExits" }
if ($pavState -notmatch 'status=STOPPED') { throw 'Supervisor did not write STOPPED state.' }
Write-Output "Supervisor test passed. Starts=$pavStarts Exits=$pavExits"
