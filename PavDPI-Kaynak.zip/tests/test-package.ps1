[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$pavRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$pavReleaseExe = Join-Path $pavRoot 'release\PavDPI.exe'
$pavTestRoot = Join-Path $pavRoot 'build\package-test'
if (Test-Path -LiteralPath $pavTestRoot) { Remove-Item -LiteralPath $pavTestRoot -Recurse -Force }
New-Item -ItemType Directory -Path $pavTestRoot -Force | Out-Null

$pavAssembly = [System.Reflection.Assembly]::LoadFile($pavReleaseExe)
if ($pavAssembly.GetManifestResourceNames() -notcontains 'PavDPI.Payload.zip') { throw 'Embedded payload resource is missing.' }
$pavZipPath = Join-Path $pavTestRoot 'PavDPI.Payload.zip'
$pavResource = $pavAssembly.GetManifestResourceStream('PavDPI.Payload.zip')
try {
    $pavOutput = [System.IO.File]::Create($pavZipPath)
    try { $pavResource.CopyTo($pavOutput) } finally { $pavOutput.Dispose() }
}
finally { $pavResource.Dispose() }

$pavExtracted = Join-Path $pavTestRoot 'payload'
Expand-Archive -LiteralPath $pavZipPath -DestinationPath $pavExtracted
$pavManifestPath = Join-Path $pavExtracted 'manifest.sha256'
if (-not (Test-Path -LiteralPath $pavManifestPath)) { throw 'manifest.sha256 is missing.' }
$pavVerified = 0
foreach ($pavLine in (Get-Content -LiteralPath $pavManifestPath)) {
    if ([System.String]::IsNullOrWhiteSpace($pavLine)) { continue }
    if ($pavLine -notmatch '^([A-Fa-f0-9]{64})  (.+)$') { throw "Invalid manifest line: $pavLine" }
    $pavRelative = $Matches[2].Replace('/', '\')
    $pavFullPath = [System.IO.Path]::GetFullPath((Join-Path $pavExtracted $pavRelative))
    $pavAllowed = $pavExtracted.TrimEnd('\') + '\'
    if (-not $pavFullPath.StartsWith($pavAllowed, [System.StringComparison]::OrdinalIgnoreCase)) { throw "Unsafe path: $pavRelative" }
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $pavFullPath).Hash -ne $Matches[1].ToUpperInvariant()) { throw "Hash mismatch: $pavRelative" }
    $pavVerified++
}

$pavEmbeddedEngine = Join-Path $pavExtracted 'engine\PavDPI Engine.exe'
$pavSourceEngine = Join-Path $pavRoot 'third_party\engine\PavDPI Engine.exe'
if ((Get-FileHash -Algorithm SHA256 -LiteralPath $pavEmbeddedEngine).Hash -ne (Get-FileHash -Algorithm SHA256 -LiteralPath $pavSourceEngine).Hash) {
    throw 'Embedded engine differs from the pinned source binary.'
}
$pavEngineText = [System.Text.Encoding]::ASCII.GetString([System.IO.File]::ReadAllBytes($pavEmbeddedEngine))
$pavOldProduct = 'Good' + 'bye' + 'DPI'
$pavOldAuthor = 'Val' + 'dik' + 'SS'
$pavOldLabels = [regex]::Escape($pavOldProduct) + '|' + [regex]::Escape($pavOldAuthor)
if ($pavEngineText -match $pavOldLabels) { throw 'Embedded engine still contains an old product or author label.' }
if ($pavEngineText -notmatch 'https://github.com/poroksima') { throw 'Embedded engine project link is not branded for Poroksima.' }
& (Join-Path $pavExtracted 'PavDPI Service.exe') --self-test
if ($LASTEXITCODE -ne 0) { throw "Embedded service self-test failed: $LASTEXITCODE" }
$pavExpectedHash = ((Get-Content -LiteralPath (Join-Path $pavRoot 'release\SHA256SUMS.txt') -Raw).Split(' ', [System.StringSplitOptions]::RemoveEmptyEntries))[0]
$pavActualHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $pavReleaseExe).Hash
if ($pavExpectedHash -ne $pavActualHash) { throw 'Release SHA256 mismatch.' }
Write-Output "Package test passed. VerifiedFiles=$pavVerified SHA256=$pavActualHash"
