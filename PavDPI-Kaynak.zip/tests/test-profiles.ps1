[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$pavRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$pavTestRoot = Join-Path $pavRoot 'build\profile-test'
if (Test-Path -LiteralPath $pavTestRoot) { Remove-Item -LiteralPath $pavTestRoot -Recurse -Force }
New-Item -ItemType Directory -Path $pavTestRoot -Force | Out-Null
$pavCsc = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$pavTestExe = Join-Path $pavTestRoot 'TestProfiles.exe'
& $pavCsc /nologo /target:exe /platform:x64 /optimize+ "/out:$pavTestExe" `
    (Join-Path $pavRoot 'src\PavDPI.Installer\PavDPIProfile.cs') `
    (Join-Path $pavRoot 'tests\TestProfiles.cs')
if ($LASTEXITCODE -ne 0) { throw "Profile test build failed: $LASTEXITCODE" }
& $pavTestExe
if ($LASTEXITCODE -ne 0) { throw "Profile test failed: $LASTEXITCODE" }
