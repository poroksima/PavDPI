[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$pavRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
& (Join-Path $pavRoot 'scripts\build.ps1')
& (Join-Path $pavRoot 'tests\test-profiles.ps1')
& (Join-Path $pavRoot 'tests\test-service-path.ps1')
& (Join-Path $pavRoot 'tests\test-source-safety.ps1')
& (Join-Path $pavRoot 'tests\test-service-supervisor.ps1')
& (Join-Path $pavRoot 'tests\test-package.ps1')
Write-Output 'All PavDPI tests passed.'
