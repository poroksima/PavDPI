using System;

internal static class TestServicePath
{
    private static int Main()
    {
        string input = @"C:\Program Files\PavDPI\PavDPI Service.exe";
        string expected = "\"" + input + "\"";
        string actual = WindowsServiceManager.QuoteBinaryPath(input);
        if (!String.Equals(expected, actual, StringComparison.Ordinal))
        {
            Console.Error.WriteLine("Unexpected service path: " + actual);
            return 1;
        }
        Console.WriteLine("Service path test passed: " + actual);
        return 0;
    }
}
