using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

[assembly: AssemblyTitle("PavDPI Service")]
[assembly: AssemblyDescription("PavDPI Service - background connection engine supervisor")]
[assembly: AssemblyCompany("Poroksima")]
[assembly: AssemblyProduct("PavDPI")]
[assembly: AssemblyCopyright("Copyright (c) 2026 Poroksima")]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]

internal static class PavDPIServiceProgram
{
    private const string ServiceNameValue = "PavDPI";

    private static int Main(string[] args)
    {
        try
        {
            if (args.Length > 0 && String.Equals(args[0], "--self-test", StringComparison.OrdinalIgnoreCase))
            {
                return PavDPIEngineSupervisor.RunSelfTest();
            }
            if (args.Length == 2 && String.Equals(args[0], "--run-for", StringComparison.OrdinalIgnoreCase))
            {
                int seconds;
                if (!Int32.TryParse(args[1], out seconds) || seconds < 1 || seconds > 300)
                {
                    Console.Error.WriteLine("--run-for expects 1..300 seconds.");
                    return 4;
                }
                return PavDPIEngineSupervisor.RunForSeconds(seconds);
            }

            ServiceBase.Run(new PavDPIWindowsService());
            return 0;
        }
        catch (Exception exception)
        {
            PavDPILog.Write("Service fatal error: " + exception);
            return 1;
        }
    }

    private sealed class PavDPIWindowsService : ServiceBase
    {
        private PavDPIEngineSupervisor supervisor;

        public PavDPIWindowsService()
        {
            ServiceName = ServiceNameValue;
            CanStop = true;
            CanShutdown = true;
            AutoLog = false;
        }

        protected override void OnStart(string[] args)
        {
            RequestAdditionalTime(15000);
            supervisor = new PavDPIEngineSupervisor();
            supervisor.Start();
        }

        protected override void OnStop()
        {
            if (supervisor != null)
            {
                RequestAdditionalTime(15000);
                supervisor.Stop();
                supervisor.Dispose();
                supervisor = null;
            }
        }

        protected override void OnShutdown()
        {
            OnStop();
            base.OnShutdown();
        }
    }
}

internal sealed class PavDPIEngineSupervisor : IDisposable
{
    private readonly ManualResetEventSlim stopRequested = new ManualResetEventSlim(false);
    private readonly object processLock = new object();
    private readonly PavDPIEngineJob engineJob = new PavDPIEngineJob();
    private Task worker;
    private Process engineProcess;
    private bool disposed;

    public void Start()
    {
        if (worker != null)
        {
            throw new InvalidOperationException("Supervisor is already running.");
        }
        PavDPILog.Write("PavDPI service starting. Version=" + Assembly.GetExecutingAssembly().GetName().Version);
        PavDPIState.Write("STARTING", 0, ReadProfileName(), "Service is starting");
        worker = Task.Factory.StartNew(SuperviseLoop, CancellationToken.None, TaskCreationOptions.LongRunning, TaskScheduler.Default);
    }

    public void Stop()
    {
        PavDPILog.Write("PavDPI service stop requested.");
        stopRequested.Set();
        StopEngine();
        if (worker != null)
        {
            try
            {
                worker.Wait(12000);
            }
            catch (AggregateException exception)
            {
                PavDPILog.Write("Worker stop wait error: " + exception.Flatten());
            }
        }
        PavDPIState.Write("STOPPED", 0, ReadProfileName(), "Service stopped");
        PavDPILog.Write("PavDPI service stopped.");
    }

    private void SuperviseLoop()
    {
        int rapidExits = 0;
        while (!stopRequested.IsSet)
        {
            Process process = null;
            DateTime startedAt = DateTime.UtcNow;
            try
            {
                process = StartEngine();
                int processId = process.Id;
                string profile = ReadProfileName();
                PavDPIState.Write("ENGINE_RUNNING", processId, profile, "Engine is running");
                PavDPILog.Write("Engine started. PID=" + processId + " Profile=" + profile);

                while (!stopRequested.Wait(500) && !process.HasExited)
                {
                }
                if (stopRequested.IsSet)
                {
                    StopEngine();
                    break;
                }

                int exitCode = process.HasExited ? process.ExitCode : -1;
                TimeSpan uptime = DateTime.UtcNow - startedAt;
                PavDPILog.Write("Engine exited unexpectedly. ExitCode=" + exitCode + " UptimeSeconds=" + (int)uptime.TotalSeconds);
                rapidExits = uptime.TotalSeconds < 20 ? rapidExits + 1 : 0;
            }
            catch (Exception exception)
            {
                rapidExits++;
                PavDPILog.Write("Engine start failure: " + exception);
                PavDPIState.Write("ENGINE_ERROR", 0, ReadProfileName(), exception.Message);
            }
            finally
            {
                lock (processLock)
                {
                    if (engineProcess != null)
                    {
                        try { engineProcess.Dispose(); } catch { }
                        engineProcess = null;
                    }
                }
            }

            if (!stopRequested.IsSet)
            {
                int delaySeconds = Math.Min(60, 3 + (rapidExits * 5));
                PavDPIState.Write("RESTART_WAIT", 0, ReadProfileName(), "Engine restart in " + delaySeconds + " seconds");
                stopRequested.Wait(TimeSpan.FromSeconds(delaySeconds));
            }
        }
    }

    private Process StartEngine()
    {
        string enginePath = Path.Combine(PavDPIPaths.EngineDirectory, "PavDPI Engine.exe");
        ValidateRequiredFile(enginePath, "PavDPI Engine was not found.");
        ValidateRequiredFile(Path.Combine(PavDPIPaths.EngineDirectory, "WinDivert.dll"), "WinDivert.dll was not found.");
        ValidateRequiredFile(Path.Combine(PavDPIPaths.EngineDirectory, "WinDivert64.sys"), "WinDivert64.sys was not found.");
        ValidateRequiredFile(PavDPIPaths.ProfileArgumentsPath, "PavDPI profile arguments were not found.");
        ValidateRequiredFile(PavDPIPaths.TargetsPath, "PavDPI target list was not found.");

        string arguments = File.ReadAllText(PavDPIPaths.ProfileArgumentsPath, Encoding.UTF8).Trim();
        if (String.IsNullOrWhiteSpace(arguments))
        {
            throw new InvalidDataException("PavDPI profile arguments are empty.");
        }

        ProcessStartInfo startInfo = new ProcessStartInfo();
        startInfo.FileName = enginePath;
        startInfo.Arguments = arguments;
        startInfo.WorkingDirectory = PavDPIPaths.EngineDirectory;
        startInfo.UseShellExecute = false;
        startInfo.CreateNoWindow = true;
        startInfo.RedirectStandardOutput = true;
        startInfo.RedirectStandardError = true;

        Process process = new Process();
        process.StartInfo = startInfo;
        process.OutputDataReceived += delegate(object sender, DataReceivedEventArgs eventArgs)
        {
            if (!String.IsNullOrWhiteSpace(eventArgs.Data)) { PavDPILog.Write("engine: " + eventArgs.Data); }
        };
        process.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs eventArgs)
        {
            if (!String.IsNullOrWhiteSpace(eventArgs.Data)) { PavDPILog.Write("engine-error: " + eventArgs.Data); }
        };

        if (!process.Start())
        {
            process.Dispose();
            throw new InvalidOperationException("PavDPI Engine could not be started.");
        }
        engineJob.TryAssign(process);
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();
        lock (processLock) { engineProcess = process; }
        return process;
    }

    private static void ValidateRequiredFile(string path, string message)
    {
        if (!File.Exists(path)) { throw new FileNotFoundException(message, path); }
    }

    private void StopEngine()
    {
        lock (processLock)
        {
            if (engineProcess == null) { return; }
            try
            {
                if (!engineProcess.HasExited)
                {
                    PavDPILog.Write("Stopping engine PID=" + engineProcess.Id);
                    engineProcess.Kill();
                    engineProcess.WaitForExit(5000);
                }
            }
            catch (Exception exception) { PavDPILog.Write("Engine stop error: " + exception.Message); }
        }
    }

    private static string ReadProfileName()
    {
        try
        {
            return File.Exists(PavDPIPaths.ProfileNamePath)
                ? File.ReadAllText(PavDPIPaths.ProfileNamePath, Encoding.UTF8).Trim()
                : "unknown";
        }
        catch { return "unknown"; }
    }

    public static int RunSelfTest()
    {
        string[] required =
        {
            Path.Combine(PavDPIPaths.EngineDirectory, "PavDPI Engine.exe"),
            Path.Combine(PavDPIPaths.EngineDirectory, "WinDivert.dll"),
            Path.Combine(PavDPIPaths.EngineDirectory, "WinDivert64.sys"),
            PavDPIPaths.ProfileArgumentsPath,
            PavDPIPaths.ProfileNamePath,
            PavDPIPaths.TargetsPath
        };
        foreach (string path in required)
        {
            if (!File.Exists(path)) { Console.Error.WriteLine("Missing: " + path); return 2; }
        }
        string arguments = File.ReadAllText(PavDPIPaths.ProfileArgumentsPath, Encoding.UTF8).Trim();
        if (String.IsNullOrWhiteSpace(arguments)) { Console.Error.WriteLine("Profile arguments are empty."); return 3; }
        if (arguments.Contains("--set-ttl") && !arguments.Contains("--blacklist"))
        {
            Console.Error.WriteLine("Unsafe profile: fixed TTL requires a blacklist.");
            return 5;
        }
        Console.WriteLine("PavDPI Service self-test passed.");
        return 0;
    }

    public static int RunForSeconds(int seconds)
    {
        using (PavDPIEngineSupervisor supervisor = new PavDPIEngineSupervisor())
        {
            supervisor.Start();
            Thread.Sleep(TimeSpan.FromSeconds(seconds));
            supervisor.Stop();
        }
        return 0;
    }

    public void Dispose()
    {
        if (disposed) { return; }
        disposed = true;
        engineJob.Dispose();
        stopRequested.Dispose();
    }
}

internal static class PavDPIPaths
{
    public static readonly string InstallDirectory = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
    public static readonly string EngineDirectory = Path.Combine(InstallDirectory, "engine");
    public static readonly string ConfigDirectory = Path.Combine(InstallDirectory, "config");
    public static readonly string ProfileArgumentsPath = Path.Combine(ConfigDirectory, "profile.args");
    public static readonly string ProfileNamePath = Path.Combine(ConfigDirectory, "profile.name");
    public static readonly string TargetsPath = Path.Combine(ConfigDirectory, "targets.txt");
    public static readonly string DataDirectory = ResolveDataDirectory();
    public static readonly string LogDirectory = Path.Combine(DataDirectory, "logs");
    public static readonly string LogPath = Path.Combine(LogDirectory, "PavDPI.log");
    public static readonly string StatePath = Path.Combine(DataDirectory, "state.txt");

    private static string ResolveDataDirectory()
    {
        string overridePath = Environment.GetEnvironmentVariable("PAVDPI_DATA_DIR");
        return !String.IsNullOrWhiteSpace(overridePath)
            ? Path.GetFullPath(overridePath)
            : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "PavDPI");
    }
}

internal static class PavDPILog
{
    private static readonly object Sync = new object();
    private const long MaxLogBytes = 1024 * 1024;

    public static void Write(string message)
    {
        lock (Sync)
        {
            try
            {
                Directory.CreateDirectory(PavDPIPaths.LogDirectory);
                RotateIfNeeded();
                File.AppendAllText(PavDPIPaths.LogPath, DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + " | " + message + Environment.NewLine, new UTF8Encoding(false));
            }
            catch { }
        }
    }

    private static void RotateIfNeeded()
    {
        if (!File.Exists(PavDPIPaths.LogPath) || new FileInfo(PavDPIPaths.LogPath).Length < MaxLogBytes) { return; }
        for (int index = 3; index >= 1; index--)
        {
            string source = index == 1 ? PavDPIPaths.LogPath : PavDPIPaths.LogPath + "." + (index - 1);
            string destination = PavDPIPaths.LogPath + "." + index;
            if (File.Exists(destination)) { File.Delete(destination); }
            if (File.Exists(source)) { File.Move(source, destination); }
        }
    }
}

internal static class PavDPIState
{
    private static readonly object Sync = new object();

    public static void Write(string status, int processId, string profile, string detail)
    {
        lock (Sync)
        {
            try
            {
                Directory.CreateDirectory(PavDPIPaths.DataDirectory);
                StringBuilder value = new StringBuilder();
                value.AppendLine("status=" + Clean(status));
                value.AppendLine("pid=" + processId);
                value.AppendLine("profile=" + Clean(profile));
                value.AppendLine("updated=" + DateTime.Now.ToString("o"));
                value.AppendLine("detail=" + Clean(detail));
                string temporary = PavDPIPaths.StatePath + ".tmp";
                File.WriteAllText(temporary, value.ToString(), new UTF8Encoding(false));
                if (File.Exists(PavDPIPaths.StatePath)) { File.Delete(PavDPIPaths.StatePath); }
                File.Move(temporary, PavDPIPaths.StatePath);
            }
            catch (Exception exception) { PavDPILog.Write("State write error: " + exception.Message); }
        }
    }

    private static string Clean(string value)
    {
        return value == null ? String.Empty : value.Replace("\r", " ").Replace("\n", " ");
    }
}

internal sealed class PavDPIEngineJob : IDisposable
{
    private IntPtr handle;

    public PavDPIEngineJob()
    {
        handle = CreateJobObject(IntPtr.Zero, null);
        if (handle == IntPtr.Zero) { return; }
        JOBOBJECT_EXTENDED_LIMIT_INFORMATION information = new JOBOBJECT_EXTENDED_LIMIT_INFORMATION();
        information.BasicLimitInformation.LimitFlags = 0x00002000;
        int length = Marshal.SizeOf(typeof(JOBOBJECT_EXTENDED_LIMIT_INFORMATION));
        IntPtr pointer = Marshal.AllocHGlobal(length);
        try
        {
            Marshal.StructureToPtr(information, pointer, false);
            if (!SetInformationJobObject(handle, 9, pointer, (uint)length))
            {
                CloseHandle(handle);
                handle = IntPtr.Zero;
            }
        }
        finally { Marshal.FreeHGlobal(pointer); }
    }

    public void TryAssign(Process process)
    {
        if (handle == IntPtr.Zero) { return; }
        if (!AssignProcessToJobObject(handle, process.Handle))
        {
            PavDPILog.Write("Engine job assignment skipped. Win32=" + Marshal.GetLastWin32Error());
        }
    }

    public void Dispose()
    {
        if (handle != IntPtr.Zero) { CloseHandle(handle); handle = IntPtr.Zero; }
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct JOBOBJECT_BASIC_LIMIT_INFORMATION
    {
        public long PerProcessUserTimeLimit;
        public long PerJobUserTimeLimit;
        public uint LimitFlags;
        public UIntPtr MinimumWorkingSetSize;
        public UIntPtr MaximumWorkingSetSize;
        public uint ActiveProcessLimit;
        public UIntPtr Affinity;
        public uint PriorityClass;
        public uint SchedulingClass;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct IO_COUNTERS
    {
        public ulong ReadOperationCount;
        public ulong WriteOperationCount;
        public ulong OtherOperationCount;
        public ulong ReadTransferCount;
        public ulong WriteTransferCount;
        public ulong OtherTransferCount;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct JOBOBJECT_EXTENDED_LIMIT_INFORMATION
    {
        public JOBOBJECT_BASIC_LIMIT_INFORMATION BasicLimitInformation;
        public IO_COUNTERS IoInfo;
        public UIntPtr ProcessMemoryLimit;
        public UIntPtr JobMemoryLimit;
        public UIntPtr PeakProcessMemoryUsed;
        public UIntPtr PeakJobMemoryUsed;
    }

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr CreateJobObject(IntPtr securityAttributes, string name);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool SetInformationJobObject(IntPtr job, int informationClass, IntPtr information, uint length);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool AssignProcessToJobObject(IntPtr job, IntPtr process);

    [DllImport("kernel32.dll")]
    private static extern bool CloseHandle(IntPtr handleValue);
}
