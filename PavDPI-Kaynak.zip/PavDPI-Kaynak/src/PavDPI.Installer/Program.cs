using System;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;

[assembly: AssemblyTitle("PavDPI")]
[assembly: AssemblyDescription("PavDPI 2.0 installer and connection manager")]
[assembly: AssemblyCompany("Poroksima")]
[assembly: AssemblyProduct("PavDPI")]
[assembly: AssemblyCopyright("Copyright (c) 2026 Poroksima")]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
[assembly: AssemblyInformationalVersion("2.0.0")]

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        bool createdNew;
        using (Mutex singleInstance = new Mutex(true, "Global\\PavDPI.Installer.2", out createdNew))
        {
            if (!createdNew)
            {
                MessageBox.Show(
                    "PavDPI zaten acik. Acik olan pencereyi kullan.",
                    "PavDPI",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
