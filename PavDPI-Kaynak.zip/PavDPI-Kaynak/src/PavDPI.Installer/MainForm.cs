using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

internal sealed class MainForm : Form
{
    private const int WmNcButtonDown = 0xA1;
    private const int HtCaption = 0x2;
    private readonly Color background = Color.FromArgb(30, 30, 30);
    private readonly Color panel = Color.FromArgb(40, 40, 43);
    private readonly Color panelLight = Color.FromArgb(54, 54, 58);
    private readonly Color accent = Color.FromArgb(0, 120, 212);
    private readonly Color accentGreen = Color.FromArgb(102, 176, 116);
    private readonly Color danger = Color.FromArgb(210, 92, 102);
    private readonly Color textPrimary = Color.FromArgb(245, 245, 245);
    private readonly Color textSecondary = Color.FromArgb(181, 181, 185);

    private Label statusLabel;
    private Button installButton;
    private Button uninstallButton;
    private Button testButton;
    private ProgressBar progressBar;
    private PavDPIProfile automaticProfile;
    private bool busy;

    public MainForm()
    {
        Text = "PavDPI 2.0";
        ClientSize = new Size(620, 290);
        MinimumSize = new Size(620, 290);
        MaximumSize = new Size(620, 290);
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.None;
        MaximizeBox = false;
        DoubleBuffered = true;
        BackColor = background;
        ForeColor = textPrimary;
        Font = new Font("Segoe UI", 9.5F, FontStyle.Regular, GraphicsUnit.Point);
        Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        automaticProfile = PavDPIProfile.Find("auto");
        if (automaticProfile == null) { throw new InvalidOperationException("Otomatik PavDPI profili bulunamadı."); }
        BuildInterface();
        UpdateRoundedRegion();
        MouseDown += BeginWindowDrag;
        Shown += MainForm_Shown;
        FormClosing += MainForm_FormClosing;
    }

    private void BuildInterface()
    {
        GlobeControl globe = new GlobeControl();
        globe.Location = new Point(28, 20);
        globe.Size = new Size(58, 58);
        globe.BackColor = background;
        globe.ForeColor = textPrimary;
        globe.MouseDown += BeginWindowDrag;
        Controls.Add(globe);

        Label title = new Label();
        title.Text = "PavDPI";
        title.Font = new Font("Segoe UI Semibold", 20F, FontStyle.Regular, GraphicsUnit.Point);
        title.AutoSize = true;
        title.Location = new Point(98, 31);
        title.ForeColor = textPrimary;
        title.MouseDown += BeginWindowDrag;
        Controls.Add(title);

        Button minimizeButton = CreateWindowButton("\u2014", new Point(540, 15), panelLight);
        minimizeButton.Click += delegate { WindowState = FormWindowState.Minimized; };
        Controls.Add(minimizeButton);

        Button closeButton = CreateWindowButton("\u2715", new Point(578, 15), danger);
        closeButton.Click += delegate { Close(); };
        Controls.Add(closeButton);

        RoundedPanel statusPanel = new RoundedPanel();
        statusPanel.CornerRadius = 12;
        statusPanel.Location = new Point(24, 96);
        statusPanel.Size = new Size(572, 86);
        statusPanel.BackColor = panel;
        Controls.Add(statusPanel);

        statusLabel = new Label();
        statusLabel.Text = "Kontrol ediliyor…";
        statusLabel.AutoEllipsis = true;
        statusLabel.Location = new Point(20, 16);
        statusLabel.Size = new Size(532, 28);
        statusLabel.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Regular, GraphicsUnit.Point);
        statusLabel.ForeColor = textPrimary;
        statusPanel.Controls.Add(statusLabel);

        Label statusDescription = new Label();
        statusDescription.Text = "PavDPI uygun ayarı seçer ve Windows ile birlikte çalışır.";
        statusDescription.Location = new Point(20, 52);
        statusDescription.Size = new Size(532, 20);
        statusDescription.ForeColor = textSecondary;
        statusPanel.Controls.Add(statusDescription);

        installButton = CreateButton("Kur veya onar", accent, new Point(24, 204), new Size(184, 44));
        installButton.Click += InstallButton_Click;
        Controls.Add(installButton);

        testButton = CreateButton("Bağlantıyı test et", panelLight, new Point(218, 204), new Size(200, 44));
        testButton.Click += TestButton_Click;
        Controls.Add(testButton);

        uninstallButton = CreateButton("Kaldır", panelLight, new Point(428, 204), new Size(168, 44));
        uninstallButton.ForeColor = Color.FromArgb(245, 164, 169);
        uninstallButton.Click += UninstallButton_Click;
        Controls.Add(uninstallButton);

        progressBar = new ProgressBar();
        progressBar.Location = new Point(24, 267);
        progressBar.Size = new Size(572, 4);
        progressBar.Style = ProgressBarStyle.Marquee;
        progressBar.MarqueeAnimationSpeed = 25;
        progressBar.Visible = false;
        Controls.Add(progressBar);

    }

    private Button CreateButton(string text, Color color, Point location, Size size)
    {
        RoundedButton button = new RoundedButton();
        button.CornerRadius = 8;
        button.Text = text;
        button.Location = location;
        button.Size = size;
        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderSize = 0;
        button.BackColor = color;
        button.ForeColor = Color.White;
        button.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Regular, GraphicsUnit.Point);
        button.Cursor = Cursors.Hand;
        return button;
    }

    private Button CreateWindowButton(string text, Point location, Color hoverColor)
    {
        Button button = new Button();
        button.Text = text;
        button.Location = location;
        button.Size = new Size(30, 30);
        button.FlatStyle = FlatStyle.Flat;
        button.UseVisualStyleBackColor = false;
        button.FlatAppearance.BorderSize = 0;
        button.FlatAppearance.MouseOverBackColor = hoverColor;
        button.FlatAppearance.MouseDownBackColor = hoverColor;
        button.BackColor = background;
        button.ForeColor = textPrimary;
        button.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold, GraphicsUnit.Point);
        button.Cursor = Cursors.Hand;
        button.TabStop = false;
        return button;
    }

    private void BeginWindowDrag(object sender, MouseEventArgs eventArgs)
    {
        if (eventArgs.Button != MouseButtons.Left) { return; }
        ReleaseCapture();
        SendMessage(Handle, WmNcButtonDown, HtCaption, 0);
    }

    private void UpdateRoundedRegion()
    {
        using (GraphicsPath path = RoundedShape.CreatePath(new Rectangle(0, 0, ClientSize.Width, ClientSize.Height), 18))
        {
            Region previous = Region;
            Region = new Region(path);
            if (previous != null) { previous.Dispose(); }
        }
    }

    protected override void OnResize(EventArgs eventArgs)
    {
        base.OnResize(eventArgs);
        if (ClientSize.Width > 0 && ClientSize.Height > 0) { UpdateRoundedRegion(); }
    }

    protected override CreateParams CreateParams
    {
        get
        {
            const int ClassStyleDropShadow = 0x00020000;
            CreateParams parameters = base.CreateParams;
            parameters.ClassStyle |= ClassStyleDropShadow;
            return parameters;
        }
    }

    [DllImport("user32.dll")]
    private static extern bool ReleaseCapture();

    [DllImport("user32.dll")]
    private static extern IntPtr SendMessage(IntPtr windowHandle, int message, int wordParameter, int longParameter);

    private async void MainForm_Shown(object sender, EventArgs eventArgs)
    {
        RefreshStatus();
        if (InstallerCore.RequiresUpgrade())
        {
            await InstallOrRepairAsync(true);
        }
    }

    private async void InstallButton_Click(object sender, EventArgs eventArgs)
    {
        await InstallOrRepairAsync(false);
    }

    private async Task InstallOrRepairAsync(bool startedAutomatically)
    {
        SetBusy(true);
        AppendActivity(startedAutomatically
            ? "Eski kurulum algılandı; PavDPI otomatik olarak yenileniyor…"
            : "Kurulum başlatılıyor…");
        InstallResult result = await Task.Run(delegate { return InstallerCore.Install(automaticProfile, AppendActivity); });
        AppendActivity(result.Message);
        SetBusy(false);
        RefreshStatus();
        statusLabel.ForeColor = result.Success ? accentGreen : danger;
        MessageBox.Show(
            result.Message,
            result.Success ? "PavDPI hazır" : "PavDPI kurulumu tamamlanamadı",
            MessageBoxButtons.OK,
            result.Success ? MessageBoxIcon.Information : MessageBoxIcon.Error);
        if (result.Success) { Close(); }
    }

    private async void UninstallButton_Click(object sender, EventArgs eventArgs)
    {
        DialogResult confirmation = MessageBox.Show(
            "PavDPI hizmeti ve Program Files altındaki dosyaları kaldırılsın mı?",
            "PavDPI'yi kaldır",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);
        if (confirmation != DialogResult.Yes) { return; }

        SetBusy(true);
        AppendActivity("Kaldırma başlatıldı.");
        InstallResult result = await Task.Run(delegate { return InstallerCore.Uninstall(AppendActivity); });
        AppendActivity(result.Message);
        SetBusy(false);
        RefreshStatus();
    }

    private async void TestButton_Click(object sender, EventArgs eventArgs)
    {
        SetBusy(true);
        AppendActivity("Discord ve Roblox bağlantıları test ediliyor…");
        IList<ConnectionProbeResult> results = await Task.Run(delegate { return InstallerCore.ProbeConnections(); });
        bool healthy = InstallerCore.ConnectionsHealthy(results);
        AppendActivity(healthy ? "Tüm bağlantı testleri başarılı." : "Bağlantı testi başarısız. Kur veya onar ile otomatik onarımı dene.");
        statusLabel.ForeColor = healthy ? accentGreen : danger;
        SetBusy(false);
    }

    private void RefreshStatus()
    {
        PavDPIStatus status = InstallerCore.QueryStatus();
        if (!status.Installed)
        {
            statusLabel.Text = "Kurulu değil";
            statusLabel.ForeColor = textSecondary;
            return;
        }
        if (status.ServiceRunning && status.EngineRunning)
        {
            statusLabel.Text = "Çalışıyor";
            statusLabel.ForeColor = accentGreen;
        }
        else
        {
            statusLabel.Text = "Sorun algılandı  ·  Servis " + (status.ServiceRunning ? "açık" : "kapalı") + "  ·  Motor " + status.EngineState + "  ·  " + status.Detail;
            statusLabel.ForeColor = danger;
        }
    }

    private void SetBusy(bool value)
    {
        if (InvokeRequired) { BeginInvoke(new Action<bool>(SetBusy), value); return; }
        busy = value;
        progressBar.Visible = value;
        installButton.Enabled = !value;
        uninstallButton.Enabled = !value;
        testButton.Enabled = !value;
        UseWaitCursor = value;
    }

    private void AppendActivity(string message)
    {
        if (InvokeRequired) { BeginInvoke(new Action<string>(AppendActivity), message); return; }
        statusLabel.Text = message.Replace("\r", " ").Replace("\n", " ");
    }

    private void MainForm_FormClosing(object sender, FormClosingEventArgs eventArgs)
    {
        if (!busy) { return; }
        eventArgs.Cancel = true;
        AppendActivity("İşlem tamamlanana kadar pencere açık kalmalı.");
    }
}

internal static class RoundedShape
{
    public static GraphicsPath CreatePath(Rectangle bounds, int radius)
    {
        GraphicsPath path = new GraphicsPath();
        int diameter = Math.Max(2, radius * 2);
        Rectangle rectangle = new Rectangle(bounds.X, bounds.Y, Math.Max(1, bounds.Width - 1), Math.Max(1, bounds.Height - 1));
        diameter = Math.Min(diameter, Math.Min(rectangle.Width, rectangle.Height));
        path.AddArc(rectangle.Left, rectangle.Top, diameter, diameter, 180, 90);
        path.AddArc(rectangle.Right - diameter, rectangle.Top, diameter, diameter, 270, 90);
        path.AddArc(rectangle.Right - diameter, rectangle.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(rectangle.Left, rectangle.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }

    public static void Apply(Control control, int radius)
    {
        if (control.Width <= 0 || control.Height <= 0) { return; }
        using (GraphicsPath path = CreatePath(control.ClientRectangle, radius))
        {
            Region previous = control.Region;
            control.Region = new Region(path);
            if (previous != null) { previous.Dispose(); }
        }
    }
}

internal sealed class RoundedPanel : Panel
{
    private int cornerRadius = 14;

    public int CornerRadius
    {
        get { return cornerRadius; }
        set { cornerRadius = Math.Max(1, value); RoundedShape.Apply(this, cornerRadius); }
    }

    protected override void OnResize(EventArgs eventArgs)
    {
        base.OnResize(eventArgs);
        RoundedShape.Apply(this, cornerRadius);
    }
}

internal sealed class RoundedButton : Button
{
    private int cornerRadius = 10;

    public int CornerRadius
    {
        get { return cornerRadius; }
        set { cornerRadius = Math.Max(1, value); RoundedShape.Apply(this, cornerRadius); }
    }

    protected override void OnResize(EventArgs eventArgs)
    {
        base.OnResize(eventArgs);
        RoundedShape.Apply(this, cornerRadius);
    }
}

internal sealed class GlobeControl : Control
{
    public GlobeControl()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
    }

    protected override void OnPaint(PaintEventArgs eventArgs)
    {
        base.OnPaint(eventArgs);
        Graphics graphics = eventArgs.Graphics;
        graphics.SmoothingMode = SmoothingMode.AntiAlias;
        RectangleF badge = new RectangleF(1, 1, Width - 2, Height - 2);
        using (SolidBrush badgeFill = new SolidBrush(Color.FromArgb(27, 29, 34)))
        {
            graphics.FillEllipse(badgeFill, badge);
        }

        RectangleF globe = new RectangleF(6, 6, Width - 12, Height - 12);
        using (Pen line = new Pen(Color.FromArgb(224, 224, 228), 1.35F))
        {
            graphics.DrawEllipse(line, globe);
            graphics.DrawEllipse(line, globe.X + globe.Width * 0.23F, globe.Y, globe.Width * 0.54F, globe.Height);
            graphics.DrawEllipse(line, globe.X + globe.Width * 0.39F, globe.Y, globe.Width * 0.22F, globe.Height);
            graphics.DrawArc(line, globe.X, globe.Y + globe.Height * 0.20F, globe.Width, globe.Height * 0.60F, 180, 180);
            graphics.DrawArc(line, globe.X, globe.Y + globe.Height * 0.20F, globe.Width, globe.Height * 0.60F, 0, 180);
            graphics.DrawLine(line, globe.Left, globe.Top + globe.Height / 2F, globe.Right, globe.Top + globe.Height / 2F);
        }
    }
}
