using System;
using System.Collections.Generic;

internal static class TestProfiles
{
    private static int Main()
    {
        IList<PavDPIProfile> profiles = PavDPIProfile.All();
        IList<PavDPIProfile> candidates = PavDPIProfile.AutomaticCandidates();
        if (profiles.Count < 5 || candidates.Count != 4) { Console.Error.WriteLine("Unexpected profile count."); return 1; }
        if (!profiles[0].IsAutomatic) { Console.Error.WriteLine("Automatic profile is not first."); return 2; }

        HashSet<string> ids = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (PavDPIProfile profile in profiles)
        {
            if (!ids.Add(profile.Id)) { Console.Error.WriteLine("Duplicate profile id: " + profile.Id); return 3; }
            if (!String.Equals(profile.DisplayName, "Otomatik", StringComparison.Ordinal))
            {
                Console.Error.WriteLine("User-facing profile name is not generic: " + profile.DisplayName);
                return 9;
            }
            if (!profile.IsAutomatic && String.IsNullOrWhiteSpace(profile.Arguments)) { return 4; }
            if (profile.Arguments.Contains("--set-ttl") && !profile.Arguments.Contains("--blacklist"))
            {
                Console.Error.WriteLine("Unsafe global fixed TTL: " + profile.Id);
                return 5;
            }
            if (!profile.IsAutomatic && (!profile.Arguments.Contains("--blacklist") || !profile.Arguments.Contains("targets.txt")))
            {
                Console.Error.WriteLine("Profile is not limited to target domains: " + profile.Id);
                return 8;
            }
        }
        PavDPIProfile targeted = PavDPIProfile.Find("turkey-targeted");
        if (targeted == null || !targeted.Arguments.Contains("targets.txt")) { return 6; }
        if (targeted.Arguments.IndexOf("proton", StringComparison.OrdinalIgnoreCase) >= 0) { return 7; }
        Console.WriteLine("Profile test passed. Profiles=" + profiles.Count + " AutoCandidates=" + candidates.Count);
        return 0;
    }
}
