using System;
using System.Threading;

internal static class TestEngine
{
    private static int Main(string[] args)
    {
        Console.WriteLine("Synthetic PavDPI Engine started.");
        Thread.Sleep(2200);
        Console.Error.WriteLine("Synthetic engine exit for restart test.");
        return 23;
    }
}
