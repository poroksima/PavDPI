[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$pavRoot = [System.IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$pavSources = Get-ChildItem -LiteralPath (Join-Path $pavRoot 'src') -Recurse -File -Filter '*.cs'
$pavText = ($pavSources | ForEach-Object { Get-Content -LiteralPath $_.FullName -Raw }) -join "`n"
foreach ($pavForbidden in @('sc.exe','taskkill.exe','NotifyIcon','ToastNotification','195.175.254.2 --')) {
    if ($pavText.IndexOf($pavForbidden, [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
        throw "Forbidden source pattern found: $pavForbidden"
    }
}
if ($pavText -notmatch 'QuoteBinaryPath') { throw 'Native service path quoting helper is missing.' }
if ($pavText -notmatch 'previousPavDpi') { throw 'Rollback service snapshot is missing.' }
if ($pavText -notmatch 'PavDPI Engine\.exe') { throw 'Engine process name is missing.' }
Write-Output "Source safety test passed. Files=$($pavSources.Count)"
